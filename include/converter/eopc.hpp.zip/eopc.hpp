/*
 * MIT License
 *
 * Copyright © 2017 S5Lab
 * Created by Leonardo Parisi (leonardo.parisi[at]gmail.com)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

#ifndef _H_ASTRO_EOPC_H
#define _H_ASTRO_EOPC_H

#include <cstdlib>
#include <cstdio>

#include <sys/types.h>
#include <sys/stat.h>

#include <cmath>
#include <cfloat>

#include <cstring>
#include <cerrno>

#include <vector>
#include <array>

#include <string>

#include <vallado/astTime.h>
#include <vallado/EopSpw.h>

#include "../utils.h"

#define WITH_CSPLINE
//#define WITH_LAGRANGE

/*****************************************************************************/
// namespace astro
/*****************************************************************************/
namespace astro {

   /*****************************************************************************/
  // class eopc
  /*****************************************************************************/
  class eopc {
    
  private:
    
    // variabile che mi dice se devo fare l'update dei file
    static bool toUpdate;
    
    // data file type
    enum dataFileType { FILE_IAU1980, FILE_IAU2000, FILE_TAIUTC };
    
    // data type
    enum dataType { JDAY, UTC, LOD, XP, YP, DPSI, DEPS, DAT, TYPE_NUM };
    
    // data type string
    static const char dataStr[8][5];
    
    // data referred to the precession-nutation model IAU 1980
    static const char  urlEopcIAU1980[PATH_MAX];
    static const char fileEopcIAU1980[PATH_MAX];
    
    // data referred to the precession-nutation model IAU 2000
    static const char  urlEopcIAU2000[PATH_MAX];
    static const char fileEopcIAU2000[PATH_MAX];
    
    // data for difference between tai and utc
    static const char  urlEopcTaiUtc[PATH_MAX];
    static const char fileEopcTaiUtc[PATH_MAX];
    
    // first eopc data 1/1/1962 in jDay
    static double jDayMin;
  
    // last eopc data in jDay
    static double jDayMax;
    
    // Data struct format:
    // [0] jDay     - julian day
    // [1] dut1     - ifference between UT1 and UTC    sec
    // [2] lod      - excess length of day             sec
    // [3] xp       - polar motion coefficient         rad
    // [4] yp       - polar motion coefficient         rad
    // [5] dpsi     - delta psi correction to gcrf     rad
    // [5] deps     - delta eps correction to gcrf     rad
    // [6] dat      - difference between TAI and UTC   sec
    static std::vector< std::array<double, 8> > data;

    // variabile che indica l'utimo giorno con cui si era interpolato
    static double lastInterpolatedJDay;
    
    // jDay su cui sono nomalizate le x in lagrange
    static double jDayNormalization;
    
    // vettore con i coefficienti dell'interpolazione
    static std::vector< std::vector<double> > coefficients;
    
    // Hide default constructor
    eopc() {}
    
  public:
    
    /*****************************************************************************/
    // init
    /*****************************************************************************/
    static void init(int days = 1, bool verbose = false) {
      
      // aggiorno i file
      //update(days, verbose);
      
      if(toUpdate){
      
        data = std::vector< std::array<double, 8> >();
        
        // carico i dati (l'ordine e' importante)
        load(FILE_IAU1980, 14);
        load(FILE_IAU2000, 14);
        load(FILE_TAIUTC,   2);
      
        // mi segno che mi sono aggiornato i file
        toUpdate = false;
        
      }
        
    }
    
    
    /*****************************************************************************/
    // getParameters
    /*****************************************************************************/
    static void getParameters(const std::vector<double> & jday, size_t winSize, std::vector<double> & xp, std::vector<double> & yp, std::vector<double> & lod, std::vector<double> & dpsi, std::vector<double> & deps, std::vector<double> & jdut1, std::vector<double> & ttt) {
     
      xp.resize(jday.size());
      yp.resize(jday.size());
      lod.resize(jday.size());
      dpsi.resize(jday.size());
      deps.resize(jday.size());
      jdut1.resize(jday.size());
      ttt.resize(jday.size());
      
      for(int i=0; i<jday.size(); ++i) getParameters(jday[i], winSize, xp[i], yp[i], lod[i], dpsi[i], deps[i], jdut1[i], ttt[i]);
      
    }
    
    /*****************************************************************************/
    // getParameters
    /*****************************************************************************/
    static void getParameters(double jDay, size_t winSize, double & xp, double & yp, double & lod, double & dpsi, double & deps, double & jdut1, double & ttt) {

      // mi calcolo se serve i coefficienti per l'interpolazione
      findInterpolationCoefficients(jDay, winSize);
      
      //S5S::Date(jDay).println();
      
      // tempo esatto in cui voglio intepolare
      // tolgo a jDay jdJustDay per via della normalizzazione
      double time = jDay - lastInterpolatedJDay;
      
#ifdef WITH_LAGRANGE
      // interpolo i dati
             xp   = lagrange::interpolate(time, coefficients[XP]);
             yp   = lagrange::interpolate(time, coefficients[YP]);
             lod  = lagrange::interpolate(time, coefficients[LOD]);
      double dut1 = lagrange::interpolate(time, coefficients[UTC]);
             dpsi = lagrange::interpolate(time, coefficients[DPSI]);
             deps = lagrange::interpolate(time, coefficients[DEPS]);
      double dat  = lagrange::interpolate(time, coefficients[DAT]);
#endif
      
#ifdef WITH_CSPLINE
      // interpolo i dati
      xp   = cspline::interpolate(time, coefficients[XP]);
      yp   = cspline::interpolate(time, coefficients[YP]);
      lod  = cspline::interpolate(time, coefficients[LOD]);
      double dut1 = cspline::interpolate(time, coefficients[UTC]);
      dpsi = cspline::interpolate(time, coefficients[DPSI]);
      deps = cspline::interpolate(time, coefficients[DEPS]);
      double dat  = cspline::interpolate(time, coefficients[DAT]);
#endif
      
      get_jdut1_ttt(jDay, dut1, dat, jdut1, ttt);
      
    }
    
  private:
    
    /*****************************************************************************/
    // get_jdut1_ttt
    /*****************************************************************************/
    static void get_jdut1_ttt(double jDay, double dut1, int dat, double & jdut1, double & ttt) {
      
      // variabli di appoggio per la data
      int year, mon, day, hr, min; double sec;
      
      // converto il giorno giuliano in data "normale"
      //astTime::invjday(jDay, 0, year, mon, day, hr, min, sec);
      Date::invjday(jDay, 0, day, mon, year, hr, min, sec);
      
      
      // variabli di appoggio per la conversione
      double ut1, tut1, /*jdut1,*/ jdut1Frac, utc, tai, tt, /*ttt,*/ jdtt, jdttFrac, tdb, ttdb, jdtdb, jdtdbFrac, tcg, jdtcg, jdtcgFrac, tcb, jdtcb, jdtcbFrac;
      
      // converto
      astTime::convtime(year, mon, day, hr, min, sec, 0, dut1, dat, ut1, tut1, jdut1, jdut1Frac, utc, tai, tt, ttt, jdtt, jdttFrac, tdb, ttdb, jdtdb, jdtdbFrac, tcg, jdtcg, jdtcgFrac, tcb, jdtcb, jdtcbFrac);
      
    }
    
    /*****************************************************************************/
    // findInterpolationCoefficients
    /*****************************************************************************/
    static void findInterpolationCoefficients(double jDay, size_t winSize) {
      
      // variabli di appoggio
      int year, mon, day, hr, min; double sec;
      
      // converto il giorno giuliano in data "normale"
      Date::invjday(jDay, 0, day, mon, year, hr, min, sec);
      
      // variabili di appoggio
      double jdJustHMD, dummy;
      
      // mi converto in data giuliana solo anno/mese/giorno e anno/mese
      astTime::jday(year, mon, day, 0, 0, 0, jdJustHMD, dummy);
      
      // devo ricalcolarmi i coefficienti
      if(lastInterpolatedJDay != jdJustHMD) {
        
        // se e' troppo vecchio rispetto ai dati do errore
        if(jdJustHMD < jDayMin || jdJustHMD > jDayMax) {
          fprintf(stderr, "eopc error: the data must be between %s and %s\n", Date(jDayMin).toGregorianDateString(), Date(jDayMax).toGregorianDateString());
          abort();
        }
        
        // la riga su cui centrare la finestra
        size_t row = 0;
        
        // cerco la riga corrispondente alla data nei dati
        for(; row<data.size(); ++row)
          if(data[row][0] == jdJustHMD) break;
        
        // la finestra di interpolazione deve essere dispari
        if(winSize % 2 == 0) ++winSize;
        
        // mi calcolo la meta' della lunghezza della finestra
        size_t halfWinSize = trunc(winSize*0.5);
        
        // definisco la finestra d'interpolazione
        size_t start = row - halfWinSize;
        size_t end   = row + halfWinSize;
        
        // TODO: controlla il calcolo della finestra
        if((long)(row - halfWinSize) < 0) { start = 0; end = row + winSize; }
        if(end >= data.size())            { end = data.size() - 1; start = data.size() - winSize; }
      
        // variabile con i dati su cui interpolare sono TYPE_NUM+1 perche TAIUTC ho bisogno di piu' spazio
        std::vector< std::vector<double> > localData(TYPE_NUM);
        
        // riempio i dati per i vari TYPE_NUM
        for(int j=0; j<TYPE_NUM; ++j) {
          
          // se sto riempendo i dati del giorno li normalizzo
          if(j==JDAY) {
            localData[JDAY].resize(winSize);
            for(size_t i=0; i<winSize; ++i)
              localData[JDAY][i] = data[i+start][j] - jdJustHMD;
          }
          
          // riempio gli altri dati
          if(j>JDAY) {
            localData[j].resize(winSize);
            for(size_t i=0; i<winSize; ++i)
              localData[j][i] = data[i+start][j];
          }
          
        }
        
#if(0)
        for(int i=1; i<TYPE_NUM; ++i){
          for(size_t j=0; j<winSize; ++j)
            printf("%s %f %f\n", dataStr[i], localData[0][j]+jdJustHMD, localData[i][j]);
          printf("\n\n");
        }
#endif
        
#ifdef WITH_LAGRANGE
        // parto da uno perche in [0] ci sono le date
        for(int i=1; i<coefficients.size(); ++i)
          coefficients[i] = lagrange::findCoefficients(localData[JDAY], localData[i]);
#endif
        
#ifdef WITH_CSPLINE
        // parto da uno perche in [0] ci sono le date
        for(int i=1; i<coefficients.size(); ++i)
          coefficients[i] = cspline::findCoefficients(localData[JDAY], localData[i]);
#endif
        
        // mi segno per quale giorno ho intepolato i dati
        lastInterpolatedJDay = jdJustHMD;
      
      }
        
    }
    
    /*****************************************************************************/
    // update
    /*****************************************************************************/
    static void update(int days, bool verbose) {
      
      if(verbose) fprintf(stderr, "updating eopc data file...\n");
      
      // current time in second since January 1, 1970
      time_t currentTime = time(NULL);
      
      // get creation time of the IAU1980 and IAU2000 data file
      struct stat stIAU1980; time_t timeIAU1980 = 0; if(stat(fileEopcIAU1980, &stIAU1980) == 0) { timeIAU1980 = stIAU1980.st_mtime; }
      struct stat stIAU2000; time_t timeIAU2000 = 0; if(stat(fileEopcIAU2000, &stIAU2000) == 0) { timeIAU2000 = stIAU2000.st_mtime; }
      struct stat stTAIUTC;  time_t timeTAIUTC  = 0; if(stat(fileEopcIAU2000, &stTAIUTC)  == 0) { timeTAIUTC  =  stTAIUTC.st_mtime; }
      
      // days in second
      time_t maxAge = 60 * 60 * 24 * days;
      
      if(currentTime-timeIAU1980 > maxAge)
        if(curl::get(urlEopcIAU1980, fileEopcIAU1980, false, true)) fprintf(stderr, "warning epoc not able to update IAU1980 data file\n");
      
      if(currentTime-timeIAU2000 > maxAge)
        if(curl::get(urlEopcIAU2000, fileEopcIAU2000, false, true)) fprintf(stderr, "warning epoc not able to update IAU2000 data file\n");
      
      if(currentTime-timeTAIUTC > maxAge)
        if(curl::get(urlEopcTaiUtc, fileEopcTaiUtc,   false, true)) fprintf(stderr, "warning epoc not able to update IAU2000 data file\n");
      
      if(currentTime-timeIAU1980 > maxAge || currentTime-timeIAU2000 > maxAge || currentTime-timeTAIUTC > maxAge) toUpdate = true;
      
    }
    
    /*****************************************************************************/
    // load
    /*****************************************************************************/
    static void load(dataFileType fileType, int lineToSkip) {
      
      char filename[PATH_MAX];
      
      if(fileType == FILE_IAU1980) strcpy(filename, fileEopcIAU1980);
      if(fileType == FILE_IAU2000) strcpy(filename, fileEopcIAU2000);
      if(fileType == FILE_TAIUTC)  strcpy(filename, fileEopcTaiUtc);
      
      // Files reading strategy and conversion:
      //
      // IAU1980 colonna 4 [MJD], 7 [UTC], 8 [LOD], 9 [dPsi] e 10 [dEps] colonne totali 16 skip 14
      // IAU2000 colonna 9 [XP] e 10 [YP] e colonne totali 16 skip 14
      // TAIUTC  colonna 5 [JDAY], 7 [DAT] colonne totali 15 skip 2
      //
      // [MJD]     => [Jday] = [MJD] + 2400000.5
      // [UTC]     =>
      // [LOD]     =>
      // [XP]      => [rad]  = [XP]   * (M_PI / 180.0)
      // [YP]      => [rad]  = [YP]   * (M_PI / 180.0)
      // [dPsi]    => [rad]  = [dPsi] * (M_PI / 180.0)
      // [dPsi]    => [rad]  = [dPsi] * (M_PI / 180.0)
      // [DAT]     =>
      // [JDAY]    =>
      
      FILE * input = fopen(filename, "r");
      
      if(input == NULL){
        fprintf(stderr, "error in open the file: \"%s\": %s\n", filename, strerror(errno));
        abort();
      }
      
      // contatore del numero righe lette
      unsigned int lineRead = 0;
      
      // variabile di appoggio lettura
      double dummy; char dummyStr[2048];
      
      // variabile di appoggio lettura
      char line[2048];
      
      // ciclo su tutte le linee del file
      while(fgets(line, 2048, input)){
        
        if(++lineRead<=lineToSkip) continue;
        
        // carico i valori per IAU1980
        if(fileType == FILE_IAU1980) {
          
          data.push_back(std::array<double, 8>());
          
          std::array<double, 8> & lastRow = data.back();
          
          sscanf(line, "%lf %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf",
                 &dummy, &dummy, &dummy, &lastRow[JDAY], &dummy, &dummy, &lastRow[UTC], &lastRow[LOD], &lastRow[DPSI], &lastRow[DEPS], &dummy, &dummy, &dummy, &dummy, &dummy, &dummy);
          
          lastRow[JDAY] += 2400000.5;
          
          lastRow[DPSI] = Radians(lastRow[DPSI]);
          lastRow[DEPS] = Radians(lastRow[DEPS]);
          
          if(lastRow[JDAY] < jDayMin) jDayMin = lastRow[JDAY];
          if(lastRow[JDAY] > jDayMax) jDayMax = lastRow[JDAY];
            
        }
        
        if(fileType == FILE_IAU2000) {
          
          std::array<double, 8> & row = data[lineRead - lineToSkip];
          
          sscanf(line, "%lf %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf",
                 &dummy, &dummy, &dummy, &dummy, &dummy, &dummy, &dummy, &dummy, &row[XP], &row[YP], &dummy, &dummy, &dummy, &dummy, &dummy, &dummy);
          
          row[XP] = Radians(row[XP]);
          row[YP] = Radians(row[YP]);
          
        }
        
        if(fileType == FILE_TAIUTC) {
          
          double jDay, dat;
          
          sscanf(line, "%lf %s %lf %s %lf %s %lf %s %s %s %s %s %s %lf %s",
                 &dummy, dummyStr, &dummy, dummyStr, &jDay, dummyStr, &dat, dummyStr, dummyStr, dummyStr, dummyStr, dummyStr, dummyStr, &dummy, dummyStr);
          
          for(std::size_t i=0; i<data.size(); ++i) if(data[i][JDAY] >= jDay) data[i][DAT] = dat;
          
        }
          
      }
      
      fclose(input);
      
    }

  };

  /*****************************************************************************/
  // static class variable definitions
  /*****************************************************************************/
  std::vector< std::array<double, 8> > eopc::data = std::vector< std::array<double, 8> >();

  // data type string
  const char eopc::dataStr[8][5] = { "JDAY", "XP", "YP", "LOD", "UTC", "DPSI", "DEPS", "DAT" };
  
  // data referred to the precession-nutation model IAU 1980
  const char  eopc::urlEopcIAU1980[PATH_MAX] = "ftp://hpiers.obspm.fr/iers/series/opa/eopc04";
  const char eopc::fileEopcIAU1980[PATH_MAX] = "/usr/local/include/S5S/data/eopc_IAU1980.dat";
  
  // data referred to the precession-nutation model IAU 2000
  const char  eopc::urlEopcIAU2000[PATH_MAX] = "ftp://hpiers.obspm.fr/iers/series/opa/eopc04_IAU2000";
  const char eopc::fileEopcIAU2000[PATH_MAX] = "/usr/local/include/S5S/data/eopc_IAU2000.dat";
  
  // data for difference between tai and utc
  const char  eopc::urlEopcTaiUtc[PATH_MAX] = "http://maia.usno.navy.mil/ser7/tai-utc.dat";
  const char eopc::fileEopcTaiUtc[PATH_MAX] = "/usr/local/include/S5S/data/tai-utc.dat";
  
  // first eopc data 1/1/1962 in jDay
  double eopc::jDayMin = -DBL_MAX;
 
  // last eopc data in jDay
  double eopc::jDayMax = DBL_MAX;
  
  // variabile che indica l'utimo giorno con cui si era interpolato
  double eopc::lastInterpolatedJDay = 0;
  
  // jDay su cui sono nomalizate le x in lagrange
  double eopc::jDayNormalization = 0;
  
  // vettore con i coefficienti dell'interpolazione
  std::vector< std::vector<double> > eopc::coefficients = std::vector< std::vector<double> >(TYPE_NUM);

  // variablie che mi dice se devo fare l'update dei file
  bool eopc::toUpdate = true;
  
} /* namespace astro */

#endif /* _H_ASTRO_EOPC_H */















#if(0)

static void load() {
  
  FILE * input = fopen(filename, "r");
  
  if(input == NULL){
    fprintf(stderr, "error in open the file: \"%s\": %s\n", filename, strerror(errno));
    abort();
  }
  
  // variabile di appoggio lettura
  char line[2048];
  
  // ciclo su tutte le linee del file
  while(fgets(line, 2048, input)) {
    
    if(strcmp(line, "BEGIN OBSERVED") == 0 || strcmp(line, "BEGIN PREDICTED") == 0) {
      
      while(fgets(line, 2048, input)) {
        
        if(strcmp(line, "END OBSERVED") == 0 || strcmp(line, "END PREDICTED") == 0) break;
        
        dataIAU.push_back(std::array<double, 7>());
        
        std::array<double, 7> & row = dataIAU.back();
        
        sscanf(line, "%lf %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf",
               &dummy, &dummy, &dummy, &row[JDAY], &row[XP], &row[YP], &row[DUT1], &row[LOD], &row[DPSI], &row[DEPS], &dummy, &dummy, &row[DAT]);
        
        
      }
      
    }
    
  }
  
  fclose(input);
  
}


#endif


